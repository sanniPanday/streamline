import React from 'react'

function Navber() {
  return (
    <div className="bg-black text-white  text-3xl p-10">
       <h1 className=" text-red-500"> Tailwind is Working!eyhrt</h1>
     </div>
  )
}

export default Navber
