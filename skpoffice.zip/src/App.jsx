import React from "react";
import Navber from "./components/Navber";

function App() {
  return (
    <div>
      <Navber/>
    </div>
    // <div className="bg-black text-white  text-3xl p-10">
    //   <h1 className="text-3xl"> Tailwind is Working!eyhrt</h1>
    // </div>
  );
}

export default App;
